from django.urls import path
from . import views  # Import views from the current package

urlpatterns = [
    path("", views.Index, name="home"),
    path("about/", views.About, name="about"),
    path("contact/", views.Contact, name="contact"),
    path("admin_login", views.Login, name="login"),
    path("logout", views.Logout_admin, name="logout"),

    path("view_doctor", views.View_Doctor, name="view_doctor"),
    path("add_doctor", views.Add_Doctor, name="add_doctor"),
    path("delete_doctor/<int:pid>", views.Delete_Doctor, name="delete_doctor"),

    path("view_pateint/", views.View_Pateint, name="view_pateint"),
    path("delete_patient/<int:pk>/", views.Delete_Patient, name="delete_patient"),  # Adjust view function name as per your im
    path("add_patient", views.Add_Pateint, name="add_patient"),


    path('view_appointment/', views.View_Appointment, name="view_appointment"),
    path('add_appointment',views.Add_Appointment,name="add_appointment"),
    path("delete_appointment/<int:pk>/", views.Delete_Appointment, name="delete_appointment"), 






]
