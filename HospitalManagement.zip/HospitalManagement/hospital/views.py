from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from .models import*
def About(request):
    return render(request, "about.html")

def Contact(request):
    return render(request, "contact.html")

def Index(request):
    if not request.user.is_staff:
        return redirect("login")

    # Fetch all instances from respective models
    doctors = Doctor.objects.all()
    patients = Patient.objects.all()
    appointments = Appointment.objects.all()

    # Count instances
    doc_count = doctors.count()
    pat_count = patients.count()
    app_count = appointments.count()

    # Pass counts as context dictionary
    context = {
        'doc': doc_count,
        'pat': pat_count,
        'app': app_count,
    }

    return render(request, "index.html", context)

   

def Login(request):
    error = ""
    if request.method == "POST":
        u = request.POST["uname"]
        p = request.POST["pwd"]

        user = authenticate(username=u, password=p)
        if user is not None:
            if user.is_staff:
                auth_login(request, user)
                error = "no"
            else:
                error = "yes"
        else:
            error = "yes"
    d = {"error": error}
    return render(request, "login.html", d)

def Logout_admin(request):
    if not request.user.is_staff:
        return redirect("login")
    auth_logout(request)
    return redirect("login")


def View_Doctor(request):
    if not request.user.is_staff:
        return redirect("login")
    
    doctors = Doctor.objects.all()
    context = {"doctors": doctors}  # Renamed 'doc' to 'doctors' for clarity
    
    return render(request, "view_doctor.html", context)



def Add_Doctor(request):
    error = ""
    if not request.user.is_staff:
        return redirect("login")
    
    if request.method == "POST":
        n = request.POST.get("name")
        c = request.POST.get("contact")
        s = request.POST.get("special")
        
        # Check if all required fields are provided
        if n and c and s:
            # Create Doctor object
            Doctor.objects.create(name=n, mobile=c, specialization=s)
            return redirect("view_doctor")  # Redirect after successful submission
        
        else:
            error = "yes"  # Handle invalid form data error
    
    # Prepare context data
    context = {"error": error}
    return render(request, "add_doctor.html", context)

def Delete_Doctor(request, pid):
    if not request.user.is_staff:
        return redirect("login")
    
    doctor = Doctor.objects.get(id=pid)
    doctor.delete()
    
    return redirect('view_doctor') 

def View_Pateint(request):
    if not request.user.is_authenticated or not request.user.is_staff:
        return redirect("login")
    
    patients = Patient.objects.all()
    context = {"patients": patients}
    
    return render(request, "view_pateint.html", context)

def Delete_Patient(request, pk):
    # Implementation to delete patient with id=pk
    # Example implementation:
    patient = Patient.objects.get(pk=pk)
    patient.delete()
    return redirect("view_pateint")


def Add_Pateint(request):
    error = ""
    if not request.user.is_staff:
        return redirect("login")
    
    if request.method == "POST":
        name = request.POST.get("name")
        gender = request.POST.get("gender")  # Matched with the correct 'name' attribute in the HTML form
        mobile = request.POST.get("mobile")
        add = request.POST.get("address")
        
        # Check if all required fields are provided
        if name and gender and mobile and add:
            # Create Patient object (not Doctor, assuming it's a typo in your original code)
            Patient.objects.create(name=name, gender=gender, mobile=mobile, address=add)  # Corrected variable name 'add'
            return redirect("view_pateint")  # Redirect after successful submission
        
        else:
            error = "yes"  # Handle invalid form data error
    
    # Prepare context data
    context = {"error": error}
    return render(request, "add_patient.html", context)





def View_Appointment(request):
    if not request.user.is_staff:
        return redirect("login")
    
    appointment = Appointment.objects.all()
    context = {"appointment": appointment}
    return render(request, "view_appointment.html", context)

def Delete_Appointment(request, pk):
    # Implementation to delete patient with id=pk
    # Example implementation:
    appointment = Appointment.objects.get(pk=pk)
    appointment.delete()
    return redirect("view_appointment")


def Add_Appointment(request):
    error = ""
    if not request.user.is_staff:
        return redirect("login")
    
    doctors = Doctor.objects.all()
    patients = Patient.objects.all()
    
    if request.method == "POST":
        doctor_id = request.POST.get("doctor")  # Get the selected doctor ID from the form
        patient_id = request.POST.get("patient")  # Get the selected patient ID from the form
        date1 = request.POST.get("date1")
        time1 = request.POST.get("time1")
        
        # Check if all required fields are provided
        if doctor_id and patient_id and date1 and time1:
            doctor = Doctor.objects.get(id=doctor_id)
            patient = Patient.objects.get(id=patient_id)
            
            # Create Appointment object
            Appointment.objects.create(doctor=doctor, patient=patient, date1=date1, time1=time1)
            
            return redirect("view_appointment")  # Redirect after successful submission
        
        else:
            error = "yes"  # Handle invalid form data error
    
    # Prepare context data
    context = {
        "error": error,
        "doctors": doctors,
        "patients": patients,
    }
    return render(request, "add_appointment.html", context)


